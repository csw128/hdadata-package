def hello():
    print("Hello!")